clear all;
Dis_BS2RIS = 20;
Dis_RIS2User = 0.02;
Dis_Layer = 0.02;
% Relay = Dis_BS2RIS/2;
f = 2.5E9;
M = 8;
N_width = 5; % numel of side width
K = 1;
R = 2;
Sigma = 1E-6;
loss = 0.8;
EUR_threshold = 1/6;
RISWidth = 2;
OffSet = 0;
c = 3E8;
lambda = c/f;
w = 1;

% Position Generation
User_Pos = [0, 0];
User_y = 0;
[RIS_Pos, RIS_y] = RIS_Generation(lambda, [N_width, N_width], R, Dis_RIS2User, Dis_Layer, RISWidth);
[BS_Pos, BS_y] = BS_Generation(lambda, M, R, Dis_RIS2User, Dis_BS2RIS, OffSet);

% Channel Generation
[~, f, ~] = NearFieldChannel(lambda, M, [N_width, N_width], K, R, ...
        User_Pos, User_y, RIS_Pos, RIS_y, BS_Pos, BS_y);
f1 = f(:, 1:K);
f2 = f(:, K+1:end);

% Plot: Energy on Layer 1
Layer1_Energy = reshape(f1, N_width, N_width)';
figure;
imagesc(pow2db(abs(Layer1_Energy).^2), [-35 0]);
colormap(jet); axis equal; axis off;
colorbar('Ticks', [-30 -20 -10 0], 'FontSize', 30, ...
            'TickLabelInterpreter', 'latex');
%set(gcf, 'Position', gcfPosition(r, :));
% Configurations
Num_Conf = 3;
Conf = zeros(N_width, N_width, Num_Conf);
Conf(:, :, 1) = zeros(N_width);
Conf(:, :, 2) = rand(5, 5)*pi;
Conf(:, :, 3) = [0 1 2 3 4;
                 1 2 3 4 5;
                 2 3 4 5 6;
                 3 4 5 6 7;
                 4 5 6 7 8]/9*pi;
gcfPosition_Conf = [239,501,560,420;
                    800,501,560,420;
                    1361,501,560,420];
for c = 1:Num_Conf
    figure;
    imagesc(Conf(:, :, c), [0 pi]);
    colormap(pink); axis equal; axis off;
    if c == Num_Conf
        colorbar('Ticks', [0 pi/2 pi], 'Ticklabels', {'0', '$\pi/2$' '$\pi$'}, 'FontSize', 30, ...
            'TickLabelInterpreter', 'latex');
    end
    set(gcf, 'Position', gcfPosition_Conf(c, :));
end
Conf = exp(1j.*Conf);

% Plot: Energy on Layer 2 with Different Configurations
Layer2_Energy = zeros(N_width, N_width, Num_Conf);
gcfPosition_Energy = [239,1,560,420;
                      800,1,560,420;
                      1361,0,560,420];
for c = 1:Num_Conf
    temp = f2*diag(reshape(Conf(:, :, c), 1, []).')*f1;
    Layer2_Energy(:, :, c) = reshape(temp, N_width, N_width)';
    figure;
    imagesc(pow2db(abs(Layer2_Energy(:, :, c)).^2), [-30 -10]);
    colormap(jet); axis equal; axis off;
    if c == Num_Conf
        colorbar('Ticks', [-30 -25 -20 -15 -10], 'FontSize', 30, ...
            'TickLabelInterpreter', 'latex');
    end
    set(gcf, 'Position', gcfPosition_Energy(c, :));
end