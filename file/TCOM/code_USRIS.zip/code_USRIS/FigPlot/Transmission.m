clear all;
rpt = 12;
Dis_BS2RIS = 20;
Dis_RIS2User = 0.02;
Dis_Layer = 0.02;
% Relay = Dis_BS2RIS/2;
f = 2.5E9;
M = 8;
N1 = [12, 16];
N2 = [8, 12];
K = 2;
R = 2;
Sigma = 1E-6;
loss = 0.8;
EUR_threshold = 1/6;
RISWidth = 2;
OffSet = 0;
Bits1 = 0;
Bits2 = 1;
c = 3E8;
lambda = c/f;
Pmax_dB = -3:1:3;
Pmax = 10.^(Pmax_dB/10);

tic;

[User_Pos, User_y] = User_Generation(lambda, K);
[RIS_Pos, RIS_y] = RIS_Generation(lambda, N2, R, Dis_RIS2User, Dis_Layer, RISWidth);
[BS_Pos, BS_y] = BS_Generation(lambda, M, R, Dis_RIS2User, Dis_BS2RIS, OffSet);
[g, f, ~] = NearFieldChannel(lambda, M, N2, K, R, ...
        User_Pos, User_y, RIS_Pos, RIS_y, BS_Pos, BS_y);
[SNR4, clims, UC_theta, UC_h, UC_Ratio1, UC_Ratio2, UC_SNR] ...
    = Scene4(g, f, Sigma, Pmax, rpt, R, Bits1, loss, N2, EUR_threshold);

[User_Pos, User_y] = User_Generation(lambda, K);
[RIS_Pos, RIS_y] = RIS_Generation(lambda, N1, R, Dis_RIS2User, Dis_Layer, RISWidth);
[BS_Pos, BS_y] = BS_Generation(lambda, M, R, Dis_RIS2User, Dis_BS2RIS, OffSet);
[~, f, g1] = NearFieldChannel(lambda, M, N1, K, R, ...
        User_Pos, User_y, RIS_Pos, RIS_y, BS_Pos, BS_y);
SNR1 = Scene1(g1, f(:, 1:K), Sigma, Pmax);
SNR2 = Scene2(g1, f(:, 1:K), Sigma, Pmax, rpt);
[SNR3, SNR5, Tran_h, Tran_theta, Ref_SNR, Tran_SNR, Tran_Ratio] ...
    = Scene3(g1, f(:, 1:K), Sigma, Pmax, rpt, clims, loss, N1, EUR_threshold);

% [g_Relay, f_Relay] = ChannelModel(Relay, Relay, 0, ...
%     M, N1, K, g_Fading, f_Fading, 1);
% [SNR7, SNR8, Relay_Tran_h, Relay_Tran_theta, Relay_Ref_SNR, Realy_Tran_SNR, Realy_Tran_Ratio] ...
%     = Scene3(g_Relay, f_Relay, Sigma, Pmax, rpt, clims, loss, N1);

g = NoRISChannel(lambda, M, K, User_Pos, User_y, BS_Pos, BS_y);
SNR6 = NoRIS(g, Sigma, Pmax);

toc;

SNR1 = 10*log10(SNR1);
SNR2 = 10*log10(SNR2);
SNR3 = 10*log10(SNR3);
SNR4 = 10*log10(SNR4);
SNR5 = 10*log10(SNR5);
SNR6 = 10*log10(SNR6);


Plot_P2SNR(Pmax_dB, SNR3, SNR4, SNR5, SNR6);
Plot_Pattern_Regular(UC_theta, UC_h, Tran_h, Tran_theta);
Plot_Convergence(UC_SNR, Ref_SNR, Tran_SNR);

[UC_Ratio1, UC_Ratio2, (UC_Ratio1+UC_Ratio2)/2, Tran_Ratio]