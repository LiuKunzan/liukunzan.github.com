function SNR = Scene2(g, f, Sigma, Pmax, rpt)
[w, ~] = eigs(f'*f, 1);
w = w/norm(w);
v = ones(size(g, 2), 1);
for t = 1:rpt
    b = v'*g'*diag(f*w);
    theta = exp(1j*angle(b'));
    [v, ~] = eigs(g'*diag(theta)*f*w*w'*f'*diag(theta)'*g, 1);
    SNR = abs(v'*g'*diag(theta)*f*w)^2/norm(v)^2/Sigma;
end
SNR = SNR*Pmax;
end