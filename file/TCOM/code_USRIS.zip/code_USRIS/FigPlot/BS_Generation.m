function [BS_Pos, BS_y] = BS_Generation(lambda, M, R, Dis_RIS2User, Dis_BS2RIS, OffSet)
BS_y = Dis_RIS2User*R+Dis_BS2RIS;
BS_Pos = zeros(M, 2);
for k = 1:M
    BS_Pos(k, :) = [-(ceil(M/2)-1)*lambda/2-lambda/4+(k-1)*lambda/2, 0];
end
BS_Pos = BS_Pos+OffSet;
end