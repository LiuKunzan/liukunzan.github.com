function Plot_P2SNR(Pmax_dB, SNR3, SNR4, SNR5, SNR6)
figure;
hold on;
plot(Pmax_dB, SNR4, 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 9);
plot(Pmax_dB, SNR3, 'LineWidth', 2, 'Marker', 'x', 'MarkerSize', 9);
plot(Pmax_dB, SNR5, 'LineWidth', 2, 'Marker', '^', 'MarkerSize', 9);
plot(Pmax_dB, SNR6, 'LineWidth', 2, 'Marker', 's', 'MarkerSize', 9);
box on;
grid on;
xlabel('${P}_{\rm{max}}$ (dB)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
ylabel('SNR (dB)', 'FontSize', 15, 'Fontname', 'Times', 'Interpreter', 'latex');
legend('Multi-layer UC-RIS', 'Single-layer CC-RIS', ...
    'Single-layer UC-RIS', 'No RIS', 'FontSize', 15, 'Location', 'NorthWest',...
    'Fontname', 'Times');
set(gcf, 'Position', [1119,597,560,420]);
end

