function g = NoRISChannel(lambda, M, K, User_Pos, User_y, BS_Pos, BS_y)
g = zeros(K, M);
for k = 1:K
    for m = 1:M
        Dis = DisCal([User_Pos(k, 1) User_Pos(k, 2) User_y], ...
            [BS_Pos(m, 1) BS_Pos(m, 2) BS_y]);
        g(k, m) = lambda/4/pi/Dis*exp(-1j*2*pi*Dis/lambda);
    end
end
end

