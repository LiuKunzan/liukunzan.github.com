function SNR = NoRIS(g, Sigma, Pmax)
[v, ~] = eigs(g'*g, 1);
a = g*v;
w = a/norm(a);
SNR = abs(v'*g'*w)^2/norm(v)^2/Sigma*Pmax;
end