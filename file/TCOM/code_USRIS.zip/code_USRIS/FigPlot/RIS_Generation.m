function [RIS_Pos, RIS_y] = RIS_Generation(lambda, N, R, Dis_RIS2User, Dis_Layer, RISWidth)
A = N(1);
B = N(2);
RIS_y = Dis_RIS2User+Dis_Layer*(0:R-1);
RIS_Pos = zeros(A*B, 2);
RISWidth = lambda/RISWidth;
%RISWidth = lambda/2;
for n = 1:A*B
    y = ceil(n/B);
    x = n-(y-1)*B;
    RIS_Pos(n, :) = [-(B/2-1)*RISWidth-RISWidth/2+(x-1)*RISWidth, ...
        (A/2-1)*RISWidth+RISWidth/2-(y-1)*RISWidth];
end
end