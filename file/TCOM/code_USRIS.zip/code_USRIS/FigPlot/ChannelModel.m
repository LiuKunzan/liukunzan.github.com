function [g, f] = ...
    ChannelModel(Dis_BS2RIS, Dis_RIS2User, Dis_Array, ...
    M, N1, K, g_Fading, f_Fading, R)
N = N1(1)*N1(2);
g = ones(N, M)*10^(-3)*(Dis_BS2RIS-Dis_Array*(R-1))^(-g_Fading);
if R == 1
    f = raylrnd(1, N, K).*exp(1j*2*pi*rand(N, K))*10^(-3)*Dis_RIS2User^(-f_Fading);
else
    f = zeros(N, K+N*(R-1));
    f(:, 1:K) = raylrnd(1, N, K).*exp(1j*2*pi*rand(N, K))*10^(-3)*Dis_RIS2User^(-f_Fading);
    for r = 2:R
        f(:, K+1+N*(r-2):K+N*(r-1)) = raylrnd(1, N, N).*exp(1j*2*pi*rand(N, N))*10^(-3)*Dis_Array^(-f_Fading);
    end
end
end